-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 19, 2022 at 09:00 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `mytable`
--

CREATE TABLE `mytable` (
  `id` int(11) NOT NULL,
  `first_name` varchar(10) NOT NULL,
  `last_name` varchar(14) NOT NULL,
  `email` varchar(36) NOT NULL,
  `ip_address` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mytable`
--

INSERT INTO `mytable` (`id`, `first_name`, `last_name`, `email`, `ip_address`) VALUES
(1, 'Pietra', 'Bartoszinsk ', 'pbartoszinski0@gmail.com', '1.189.126.101'),
(2, 'Jane ', 'Capper', 'jcapper1@flickr.com', '150.169.78.205'),
(3, 'Catherine', 'Philps', 'cphilps2@geocities.com', '135.28.37.185'),
(4, 'Sheila', 'Curnick', 'scurnick3@businessweek.com', '78.158.66.13'),
(5, 'Lamond', 'Charlon', 'lcharlon4@cyberchimps.com', '24.78.220.203'),
(6, 'Miner', 'Dalrymple', 'mdalrymple5@timesonline.co.uk', '43.180.8.128'),
(7, 'Garnet', 'Droghan', 'gdroghan6@zimbio.com', '221.112.210.2'),
(8, 'Giralda', 'Pleavin', 'gpleavin7@mediafire.com', '133.50.95.76'),
(9, 'Ariel', 'Scamal', 'ascamal8@jugem.jp', '67.28.6.240'),
(10, 'Pall', 'Beeze', 'pbeeze9@networksolutions.com', '147.199.12.220'),
(11, 'Sloane', 'Cleatherow', 'scleatherowa@rakuten.co.jp', '141.76.112.139'),
(12, 'Ardeen', 'Watsham', 'awatshamb@mtv.com', '210.172.179.65'),
(13, 'Spencer', 'MacConnal', 'smacconnalc@wsj.com', '80.220.68.25'),
(14, 'Adrian', 'Murfett', 'amurfettd@merriam-webster.com', '117.42.38.228'),
(15, 'Joleen', 'Maitland', 'jmaitlande@newyorker.com', '233.80.198.238'),
(16, 'Pauly', 'Desborough', 'pdesboroughf@newsvine.com', '58.225.149.73'),
(17, 'Percy', 'Gehring', 'pgehringg@scribd.com', '144.23.151.42'),
(18, 'Christiane', 'Nafzger', 'cnafzgerh@odnoklassniki.ru', '68.212.147.100'),
(19, 'Arly', 'Berston', 'aberstoni@tripadvisor.com', '115.136.27.164'),
(20, 'Lexy', 'Clash', 'lclashj@scientificamerican.com', '2.165.88.165'),
(21, 'Rafi', 'Abbatt', 'rabbattk@linkedin.com', '112.21.22.59'),
(22, 'Winna', 'Davidavidovics', 'wdavidavidovicsl@cargocollective.com', '200.140.233.24'),
(23, 'Farrand', 'Coburn', 'fcoburnm@redcross.org', '200.43.169.84'),
(24, 'Rodolphe', 'Kenworthy', 'rkenworthyn@latimes.com', '142.231.135.225'),
(25, 'Udall', 'Orum', 'uorumo@latimes.com', '181.182.176.17'),
(26, 'Thayne', 'Flynn', 'tflynnp@noaa.gov', '31.19.36.214'),
(27, 'Sutton', 'Carrol', 'scarrolq@dropbox.com', '239.1.170.182'),
(28, 'Gorden', 'Worster', 'gworsterr@tamu.edu', '2.59.32.15'),
(29, 'Bernita', 'Shaves', 'bshavess@marketwatch.com', '137.162.57.47'),
(30, 'Edith', 'Stirling', 'estirlingt@telegraph.co.uk', '8.86.106.59'),
(31, 'Ambrosi', 'Hosburn', 'ahosburnu@hhs.gov', '191.253.91.10'),
(32, 'Shirley', 'Battie', 'sbattiev@ocn.ne.jp', '30.166.91.173'),
(33, 'Brinn', 'Kenion', 'bkenionw@cbc.ca', '118.131.133.106'),
(34, 'Wayland', 'Boken', 'wbokenx@miitbeian.gov.cn', '163.107.88.249'),
(35, 'Douglas', 'Schurig', 'dschurigy@gmpg.org', '207.231.231.142'),
(36, 'Nate', 'MacClenan', 'nmacclenanz@bigcartel.com', '92.79.188.131'),
(37, 'Fredek', 'Maccrae', 'fmaccrae10@stanford.edu', '173.36.120.26'),
(38, 'Odell', 'Camier', 'ocamier11@flavors.me', '178.218.19.125'),
(39, 'Roscoe', 'Keel', 'rkeel12@msn.com', '237.13.79.129'),
(40, 'Amalle', 'Aisthorpe', 'aaisthorpe13@storify.com', '169.182.228.181'),
(41, 'Clywd', 'Dobie', 'cdobie14@rambler.ru', '194.200.90.210'),
(42, 'Scott', 'Perllman', 'sperllman15@nps.gov', '97.211.217.216'),
(43, 'Milty', 'Ormond', 'mormond16@si.edu', '220.110.71.121'),
(44, 'Jacky', 'Crummie', 'jcrummie17@histats.com', '89.126.129.244'),
(45, 'Smith', 'Feyer', 'sfeyer18@usatoday.com', '163.69.71.58'),
(46, 'Amelia', 'Frear', 'afrear19@people.com.cn', '169.160.245.121'),
(47, 'Ethan', 'Dogg', 'edogg1a@sitemeter.com', '99.167.160.34'),
(48, 'Amy', 'Pidgeley', 'apidgeley1b@npr.org', '113.162.209.202'),
(49, 'Jeffie', 'Upshall', 'jupshall1c@opera.com', '21.51.192.77'),
(50, 'Beatrisa', 'MacGinney', 'bmacginney1d@ucla.edu', '92.211.64.27'),
(51, 'Shay', 'Sline', 'ssline1e@acquirethisname.com', '155.251.198.58'),
(52, 'Stevena', 'Kunz', 'skunz1f@si.edu', '209.72.102.7'),
(53, 'Gunar', 'Drage', 'gdrage1g@bbc.co.uk', '236.73.54.37'),
(54, 'Claudette', 'Guilford', 'cguilford1h@cargocollective.com', '4.96.2.207'),
(55, 'Beatrisa', 'Winscom', 'bwinscom1i@woothemes.com', '39.92.192.65'),
(56, 'Brion', 'Rains', 'brains1j@sciencedaily.com', '70.74.56.80'),
(57, 'Langsdon', 'Hannibal', 'lhannibal1k@networkadvertising.org', '239.195.34.56'),
(58, 'Henrieta', 'Aggis', 'haggis1l@mail.ru', '25.198.20.234'),
(59, 'Gaven', 'Capelin', 'gcapelin1m@bandcamp.com', '131.89.27.90'),
(60, 'Barrie', 'Lendrem', 'blendrem1n@amazon.de', '12.145.198.51'),
(61, 'Davide', 'Stonman', 'dstonman1o@squarespace.com', '20.162.248.147'),
(62, 'Caddric', 'Grinaugh', 'cgrinaugh1p@washington.edu', '180.244.151.122'),
(63, 'Ailee', 'Pickle', 'apickle1q@spotify.com', '33.217.243.222'),
(64, 'Issiah', 'Sonner', 'isonner1r@harvard.edu', '113.3.11.48'),
(65, 'Nathanael', 'McCoid', 'nmccoid1s@toplist.cz', '94.194.216.35'),
(66, 'Fernanda', 'Butten', 'fbutten1t@goodreads.com', '124.16.156.45'),
(67, 'Skye', 'Lorence', 'slorence1u@ameblo.jp', '234.153.26.216'),
(68, 'Valera', 'Wylie', 'vwylie1v@rambler.ru', '175.163.148.206'),
(69, 'Christy', 'Ludwell', 'cludwell1w@uol.com.br', '250.210.66.237'),
(70, 'Basilius', 'Mixhel', 'bmixhel1x@godaddy.com', '241.253.132.135'),
(71, 'Jeni', 'Cotman', 'jcotman1y@sciencedaily.com', '9.252.144.101'),
(72, 'Myrtice', 'Burth', 'mburth1z@comcast.net', '242.187.70.201'),
(73, 'Georgetta', 'Parris', 'gparris20@lycos.com', '33.148.66.28'),
(74, 'Joeann', 'Slamaker', 'jslamaker21@ow.ly', '156.166.88.179'),
(75, 'Ruthy', 'Amorine', 'ramorine22@indiatimes.com', '244.124.223.99'),
(76, 'Edin', 'Zuker', 'ezuker23@thetimes.co.uk', '250.56.230.63'),
(77, 'Nelly', 'Kipping', 'nkipping24@vk.com', '209.34.163.1'),
(78, 'Brittan', 'Dicey', 'bdicey25@naver.com', '29.45.65.226'),
(79, 'Leta', 'McFadin', 'lmcfadin26@ebay.com', '117.19.146.221'),
(80, 'Lyell', 'Parken', 'lparken27@ebay.com', '136.202.181.49'),
(81, 'Lavinie', 'Prator', 'lprator28@opera.com', '206.42.169.150'),
(82, 'Davis', 'Olivera', 'dolivera29@chron.com', '21.75.68.121'),
(83, 'Bernice', 'Shalcras', 'bshalcras2a@uiuc.edu', '116.156.196.80'),
(84, 'Delia', 'Keaves', 'dkeaves2b@t.co', '210.252.16.49'),
(85, 'Sally', 'Dalley', 'sdalley2c@nasa.gov', '164.70.12.45'),
(86, 'Janna', 'Mulvagh', 'jmulvagh2d@usda.gov', '28.61.138.116'),
(87, 'Aksel', 'Byard', 'abyard2e@tuttocitta.it', '224.189.112.92'),
(88, 'Amargo', 'Godspede', 'agodspede2f@gnu.org', '185.12.211.93'),
(89, 'Barrie', 'Keymar', 'bkeymar2g@home.pl', '17.38.78.46'),
(90, 'Pamelina', 'Tune', 'ptune2h@parallels.com', '116.156.166.49'),
(91, 'Patten', 'Soldner', 'psoldner2i@cloudflare.com', '209.3.148.100'),
(92, 'Jacqueline', 'Dowall', 'jdowall2j@hexun.com', '254.111.161.227'),
(93, 'Hewet', 'O\'Growgane', 'hogrowgane2k@tinypic.com', '102.159.76.124'),
(94, 'Dyana', 'Yanshinov', 'dyanshinov2l@163.com', '59.70.11.253'),
(95, 'Bobine', 'Duchasteau', 'bduchasteau2m@discuz.net', '98.63.231.167'),
(96, 'Christine', 'Izkoveski', 'cizkoveski2n@de.vu', '229.61.165.52'),
(97, 'Willabella', 'Pleace', 'wpleace2o@answers.com', '213.26.46.96'),
(98, 'Alverta', 'Dryden', 'adryden2p@noaa.gov', '57.5.165.46'),
(99, 'Eddi', 'Arenson', 'earenson2q@theglobeandmail.com', '251.130.48.177'),
(100, 'Halie', 'Purvey', 'hpurvey2r@wikispaces.com', '80.186.4.11');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mytable`
--
ALTER TABLE `mytable`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
