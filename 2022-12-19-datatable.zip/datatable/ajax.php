<?php 

    include('class_SimpleDBClass.php');

    $db_conn = array('host' => 'localhost', 'user' => 'root','pass' => '','database' => 'test', );
    

    if(isset($_GET['rows'])){

        $db = new SimpleDBClass($db_conn);

        $q0 = $db->select("select * from mytable");

        $result =  array(   
            'status' =>"success" , 	 
            'rows'=>  $q0, 
        );

        echo json_encode($result );
    }


    if(isset($_POST['rec_id']) && isset($_POST['col_name'])){

        $db = new SimpleDBClass($db_conn);
        $rec_id     = $db->CleanDBData($_POST['rec_id']);
        $col_name   = $db->CleanDBData($_POST['col_name']);
        $col_val    = $db->CleanDBData($_POST['col_val']);

        $array_fields = array(
            $col_name=> $col_val,
        );
        $array_where = array(    
            'id' => $rec_id, 
        );
        //Call it like this:  
        $db->Update("mytable", $array_fields, $array_where);

        $result =  array(   
            'status' =>"success" , 	 
            'msg'=> 'updated successfully', 
        );
        echo json_encode($result );
    }


?>