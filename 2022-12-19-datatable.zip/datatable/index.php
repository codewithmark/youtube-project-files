<!DOCTYPE html>
<html>

<head>

	<title> Calendar - Code With Mark </title>

	<meta name="viewport" content="width=device-width, initial-scale=1">

	<meta name="description" content="This ">

	<meta name="author" content="Code With Mark">
	<meta name="authorUrl" content="http://codewithmark.com">

	<meta name="theme-color" name="#198754">

	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>   


	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.1/css/bootstrap.min.css" />
	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.2.1/js/bootstrap.bundle.min.js"></script>


	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.21/css/jquery.dataTables.min.css" integrity="sha512-1k7mWiTNoyx2XtmI96o+hdjP8nn0f3Z2N4oF/9ZZRgijyV4omsKOXEnqL1gKQNPy2MTSP9rIEWGcH/CInulptA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

	<script src="https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.21/js/jquery.dataTables.min.js" integrity="sha512-BkpSL20WETFylMrcirBahHfSnY++H2O1W+UnEEO4yNIl+jI2+zowyoGJpbtk6bx97fBXf++WJHSSK2MV4ghPcg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script> 
 
 



	<script type="text/javascript">
		$(document).ready(function($) {

			function create_table(DataArr, col) {
				var Columns = [];

				if (col) {
					Columns = col;
				}
				var GetHeaderNames = Columns.length < 1 ? DataArr[0] : Columns;
				var GetRows = DataArr;

				var d = '';
				d += '<table class="table table-hover table-bordered  cell-border" width="100%">';

				//--->Create Header- Start
				d += '<thead>';
				d += '<tr  class="tbl_header">';
				$.each(GetHeaderNames, function(i1, v1) {
					var col_value = Columns.length < 1 ? i1 : v1;
					d += '<th> <div class="header_container" col_name="' + i1 + '">' + col_value + ' </div> </th>';
				});
				d += '</tr>';
				d += '</thead>';
				//--->Create Header- End

				//--->Create Rows - Start
				d += '<tbody>';
				$.each(GetRows, function(i1, v1) {

					d += '<tr class="tbl_tr">';
					$.each(v1, function(i2, v2) {
						d += '<td class="tbl_td"> <div class="td_container" col_name="' + i2 + '">' + v2 + ' </div></td>';
					})
					d += '</tr>';
				})
				d += "</tbody>";
				//--->Create Rows - End

				d += " </table>";
				return d;
			};

			$(document).on("click", ".btn_tbl", function(event) {
				event.preventDefault();

				var call_type = $(this).attr('call_type');
				var e0 = $(document).find('.screen_data');
				var s1 = $(document).find('.template').html();

				if (call_type == "html") {
					e0.html(s1);
				} else if (call_type == "convert") {
					e0.html(s1);
					e0.find('.table').DataTable();

				} else if (call_type == "ajax") {

					$.ajax("ajax.php", {
						type: 'get',
						data: {
							rows: "all"
						},
						cache: false,
						dataType: "json",

						error: function(jqXhr, textStatus, errorMessage) {
							console.log('Error', errorMessage);
						},
						success: function(data, status, xhr) {							 
							console.log(data);
							
							var s2 = create_table(data.rows,['Record ID', 'First', 'Last', 'Email', 'IP']);
							e0.html(s2);
							
							var rec_id = 0;
							//add rec id
							e0.find('.tbl_tr').each(function (i1,v1){
								
								$(this).find('.tbl_td').each(function (i2,v2){
									var id = $(this).find('.td_container').attr('col_name');
									if(id == "id"){
										rec_id = $(this).find('.td_container').text()*1;
									}else if(id != "id") {
										$(this).find('.td_container').attr({rec_id: rec_id, contentEditable:'true'}).addClass('update_single_col');
									}
								});
							});
							e0.find('.table').DataTable();
						},
					});
				}
			});

			$(document).on("blur", ".update_single_col", function(event) {
				event.preventDefault();

				var rec_id 		= $(this).attr('rec_id');
				var col_name 	= $(this).attr('col_name');
				var col_val 	= $(this).text();	

				var e0 = $(this);

				$.ajax("ajax.php", {
						type: 'POST',
						data: {
							rec_id: rec_id, 
							col_name : col_name,
							col_val:col_val,
						},
						cache: false,
						dataType: "json",

						error: function(jqXhr, textStatus, errorMessage) {
							console.log('Error', errorMessage);
						},
						success: function(data, status, xhr) {	
							console.log(data);
							e0.after('<div id="alert" class="alert alert-success">'+data.msg+'</div>')

							setTimeout(function () {
  								// Closing the alert
								$(document).find('#alert').alert('close');
							}, 3000);
							
						},
					});
			});

		});
	</script>

</head>

<body>

	<div class="container text-center">
		<h1>Master Datatables</h1>
		<div class="p-2"></div>

		<div class="menu">
			<span class="btn btn-primary btn_tbl" call_type="html">HTML Table</span> |
			<span class="btn btn-secondary btn_tbl" call_type="convert">Convert To Datatable</span> |
			<span class="btn btn-success btn_tbl" call_type="ajax">Ajax Database Table</span> |
		</div>

		<div class="p-2"></div>
		<div class="screen_data"></div>

	</div>

	<div class="template" style="display: none;">
		<table class="table table-hover">
			<thead>
				<tr>
					<th>Firstname</th>
					<th>Lastname</th>
					<th>Email</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>John</td>
					<td>Doe</td>
					<td>john@example.com</td>
				</tr>
				<tr>
					<td>Mary</td>
					<td>Moe</td>
					<td>mary@example.com</td>
				</tr>
				<tr>
					<td>July</td>
					<td>Dooley</td>
					<td>july@example.com</td>
				</tr>
			</tbody>
		</table>
	</div>


</body>

</html>