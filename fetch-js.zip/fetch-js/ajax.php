<?php 

define("ABSPATH", str_replace("\\", "/",  dirname(__FILE__) ));

if (isset($_SERVER['HTTPS']) &&
    ($_SERVER['HTTPS'] == 'on' || $_SERVER['HTTPS'] == 1) ||
    isset($_SERVER['HTTP_X_FORWARDED_PROTO']) &&
    $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') {
  $ssl = 'https';
}
else {
  $ssl = 'http';
}
 
$app_url = ($ssl  )
          . "://".$_SERVER['HTTP_HOST']
          //. $_SERVER["SERVER_NAME"]
          . (dirname($_SERVER["SCRIPT_NAME"]) == DIRECTORY_SEPARATOR ? "" : "/")
          . trim(str_replace("\\", "/", dirname($_SERVER["SCRIPT_NAME"])), "/");

if(isset($_POST['user_name']))
{
	$el = $_POST;

	$user_name = $el['user_name'];
	$user_email = $el['user_email'];


	$upload_folder_path = '/uploads/';

	$a0 = array();
	$a1 = array();
	$a2 = array();

	
	
	//--->upload > single file > start
	if(isset($_FILES['file_obj_0']))	
	{
		$file_obj_0 = $_FILES['file_obj_0'];
		$v1 		= $file_obj_0['name'];

		$file_name = $v1;
		$ext = pathinfo($file_name, PATHINFO_EXTENSION);
		$new_file_name = 'file_obj_0_'. hash('crc32',uniqid()).'.'.$ext;

		$fileDest = ABSPATH.$upload_folder_path.$new_file_name;

		move_uploaded_file($file_obj_0['tmp_name']  ,$fileDest);

		array_push($a0,  array(
			'old_file_name' => $v1,
			'new_file_name' => $new_file_name,
			'move_to_folder'=>$app_url.$upload_folder_path,
			'download_file_path'=>$app_url.$upload_folder_path.$new_file_name,
			
		));
	
	}	
	//--->upload > single file > end
	
	//--->upload group files > 1 > start
	if(isset($_FILES['file_obj_1']))	
	{
		$file_obj_1 = $_FILES['file_obj_1'];
	
		foreach ($file_obj_1['name'] as $k1 => $v1) 
		{
			$file_name = $v1;
			$ext = pathinfo($file_name, PATHINFO_EXTENSION);
			$new_file_name = 'file_obj_1_'. hash('crc32',uniqid()).'.'.$ext;

			$fileDest = ABSPATH.$upload_folder_path.$new_file_name;

			move_uploaded_file($file_obj_1['tmp_name'][$k1] ,$fileDest);

			array_push($a1,  array(
				'old_file_name' => $v1,
				'new_file_name' => $new_file_name,
				'move_to_folder'=>$app_url.$upload_folder_path,
				'download_file_path'=>$app_url.$upload_folder_path.$new_file_name,
				
			));
		}
	}	
	//--->upload group files > 1 > end
	 
	//--->upload group files > 2 > start
	if(isset($_FILES['file_obj_2']))	
	{	 
		$file_obj_2 = $_FILES['file_obj_2'];	
		foreach ($file_obj_2['name'] as $k1 => $v1) 
		{
			$file_name = $v1;
			$ext = pathinfo($file_name, PATHINFO_EXTENSION);
			$new_file_name = 'file_obj_2_'. hash('crc32',uniqid()).'.'.$ext;

			$fileDest = ABSPATH.$upload_folder_path.$new_file_name;

			move_uploaded_file($file_obj_2['tmp_name'][$k1] ,$fileDest);

			array_push($a2,  array(
				'old_file_name' => $v1,
				'new_file_name' => $new_file_name,
				'move_to_folder'=>$app_url.$upload_folder_path,				
				'download_file_path'=>$app_url.$upload_folder_path.$new_file_name,
			));
		}	
	}
	//--->upload group files > 2 > end
	 
	

	echo json_encode(array(
		'user_name'=>$user_name,
		'user_email'=>$user_email,
		'file_obj_0' => $a0,
		'file_obj_1' => $a1,
		'file_obj_2' => $a2,
	));
}
?>