<!DOCTYPE html>
<html>
<head>
	 
	<title> Fetch JS - Code With Mark </title>

	<meta name="viewport" content="width=device-width, initial-scale=1">

 
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/css/bootstrap.min.css">


	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/js/bootstrap.min.js"></script> 

	<script type="text/javascript">
	$(document).ready(function($) 
	{ 
		//https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch
 

		$(document).on('click', '.btn_get_api_data', function(event) 
		{
			event.preventDefault();

			const url = 'https://randomuser.me/api/';

			const options = 
			{
			    method: 'GET', // *GET, POST, PUT, DELETE  
			};

			fetch(url, options)
			.then(response => response.json()) 
			.then(json => 
			{
				var str = JSON.stringify(json.results, null, 5);
				$(document).find('.post_msg').html('<pre class="bg-dark text-white">'+str+'</pre>');
			}
			).catch(err => 
				console.error(err)
			);
		});

		//--->load user screen > start
		$(document).on('click', '.btn_load_user_screen', function(event) 
		{
			event.preventDefault();

			var s1 = $(document).find('.container_user_screen').html();
			$(document).find('.post_msg').html(s1);
		});		
		//--->load user screen > end


		//--->upload file > start
		$(document).on('click', '.btn_upload_file_data', function(event) 
		{
			event.preventDefault();

			let e0  = $(document).find('.post_msg');

			//get file objects
			let f0 	= e0.find('#f0')[0].files;
			let f1 	= e0.find('#f1')[0].files;
			let f2 	= e0.find('#f2')[0].files;

			let fd 	= new FormData();

			fd.append('user_name', e0.find('.user_name').val());			
			fd.append('user_email', e0.find('.user_email').val());

			//single file
			fd.append('file_obj_0',f0[0]);

			//get all the files for group 1
			$.each(f1, function(i1, v1) 
			{ 
				fd.append('file_obj_1[]',v1);
			});


			//get all the files for group 2
			$.each(f2, function(i2, v2) 
			{ 
				fd.append('file_obj_2[]',v2);
			});

			const url = 'ajax.php';
			const options = 
			{
			    method: 'POST',
			    body: fd,
			};

			fetch(url, options)
			.then(response => response.json()) 
			.then(json => 
			{
				var s1 = $(document).find('.post_msg');
				var str = JSON.stringify(json, null, 5);
				s1.html('<pre class="bg-dark text-white">'+str+'</pre>');

				if(json.file_obj_1.length > 0)
				{
					$.each(json.file_obj_1, function(i1, v1) 
					{
						var t1 = ''
						+'<div class="1col-md-3">'
							+'<img src="'+v1.download_file_path+'" class="rounded-circle"   width="100" height="100">'
							+'<br>'
							+'<a href="'+v1.download_file_path+'" download class="btn btn-success">Download File</a>'
						+'</div>'
						;
						s1.append(t1);
					});
					s1.append('<br><br>');
				}
			}
			).catch(err => 
				console.error(err)
			);

		});		
		//--->upload file > end
 
	});
	</script>

</head>
<body>

<div style="padding-top:30px;">	

	<div class="container text-center">
		<h1 class="">Fetch - Upload Files </h1>
		<div class="btn btn-success btn_get_api_data">Get API Data</div> | <div class="btn btn-success btn_load_user_screen">Upload File</div>
		
		<br><br>

		<div class="post_msg text-left"></div>

	</div>

</div>

<div style="display:none;" class="container_user_screen">
	
	<div class="form-group">
      <label for="usr">Name:</label>
      <input type="text" class="form-control user_name">
    </div>
    <div class="form-group">
      <label >Email</label>
      <input type="text" class="form-control user_email">
    </div>

    <div class="card" style="padding:10px;">
	    <label >Single File</label>
	    <input type="file" id="f0">
	    <br>
	</div>
	<br> 

	<div class="card" style="padding:10px;">	
    	<label >Multiple Files</label>
		<input type="file" id="f1" multiple>
		<br>
	</div>
	<br> 

	<div class="card" style="padding:10px;">	
    	<label >Multiple Files</label>
		<input type="file" id="f2" multiple>
	</div>
	<br>

	<span class="btn btn-primary btn_upload_file_data">Upload</span>


</div>

</body>
</html>