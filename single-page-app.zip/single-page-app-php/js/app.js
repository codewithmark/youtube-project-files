$(document).ready(function($) {
   

    var e0 = $(document).find('.screen_data');

    
    if(window.location.hash) {
        
        var currentUrl = window.location.hash.slice(1);
        var currentUrl = window.location.hash.split("#")[1];
        var c1 = currentUrl.replace("/", "");

        var s1 = '';
        if (c1) {
            $(document).find('.screen_name').html(c1);
            s1 = $(document).find('.screen_' + c1).html();
        } else {
            s1 = $(document).find('.screen_home').html();
        }
    }
    else{
        //no hash found...so show home screen
        var s1 = $(document).find('.screen_home').html();
        $(document).find('.screen_name').html('Home');
        //e0.html(s1);
    }


    e0.html(s1);

    $(document).on('click', '.btn_menu', function(event) {
        event.preventDefault();

        var screen_name = $(this).attr('screen_name');


        window.location.hash = '/' + screen_name;

        $(document).find('.screen_name').html(screen_name);

        if (screen_name == "home") {
            var s1 = $(document).find('.screen_home').html();
            e0.html(s1);
        } else if (screen_name == "about") {
            var s1 = $(document).find('.screen_about').html();
            e0.html(s1);

        } else if (screen_name == "services") {
            var s1 = $(document).find('.screen_services').html();
            e0.html(s1);

        } else if (screen_name == "contact") {
            var s1 = $(document).find('.screen_contact').html();
            e0.html(s1);
        }

    });

});